
function szamolas(muvelet) {
    var aszam=document.getElementById("szam_1").value;
    var bszam=document.getElementById("szam_2").value;
    if (muvelet=="+") {
        var eredmeny=parseFloat(aszam)+parseFloat(bszam);
    }
    else if (muvelet=="-") {
    var eredmeny=parseFloat(aszam)-parseFloat(bszam);
    }
    else if (muvelet=="*") {
    var eredmeny=parseFloat(aszam)*parseFloat(bszam);
    }   
    else {
    var eredmeny=parseFloat(aszam)/parseFloat(bszam);
    }
    document.getElementById("eredmeny").innerHTML=eredmeny;
}

function osszeadas(){
    szamolas("+");
}

function kivonas(){
    szamolas("-");
}

function szorzas(){
    szamolas("*");
}

function osztas(){
    szamolas("/");
}